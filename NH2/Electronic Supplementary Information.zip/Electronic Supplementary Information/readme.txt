The file “Fortran code for PES” contains the ready-to-use Fortran code for the NH2 CHIPR PES.
The file “Fitted parameters of switch function” contains the fitted parameters of switch function 
The file “Parameters used in the time-dependent wave packet calculations” contains the parameters used in the time-dependent wave packet calculations.
The file “Validation of PES” contains the validations of the CHIPR PES.
The file “Interpretation of the switch function” contains the interpretation of the switch function.