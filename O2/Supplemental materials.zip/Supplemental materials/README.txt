Description:

The data includes the PECs of fourteen electronic states, TDMs and PDMs for the transitions 
between doublet and quartet states, Einstein coefficients for the X2Σ+ → A2Π, X2Σ+ → B2Σ+, 
X2Σ+ → C2Π and X2Σ+ → D2Σ+ transitions, and absorption and emission cross sections at T = 
300 K, 1000 K, 2000 K, 3000 K, 5000 K, 8000 K, 10000 K, 15000 K and p = 1atm with a resolution 
of 1 cm-1. 

File Summary:
--------------------------------------------------------------------------------------------------------------------
 FileName                                                      Explanations
--------------------------------------------------------------------------------------------------------------------
README.txt                                                     This file
Absortion_cross_section_300K_1atm_1cm-1.txt                    Absortion cross sections at T=300K, p=1atm and Δν=1cm-1
Absortion_cross_section_1000K_1atm_1cm-1.txt                   Absortion cross sections at T=1000K, p=1atm and Δν=1cm-1
Absortion_cross_section_2000K_1atm_1cm-1.txt                   Absortion cross sections at T=2000K, p=1atm and Δν=1cm-1
Absortion_cross_section_3000K_1atm_1cm-1.txt                   Absortion cross sections at T=3000K, p=1atm and Δν=1cm-1
Absortion_cross_section_5000K_1atm_1cm-1.txt                   Absortion cross sections at T=5000K, p=1atm and Δν=1cm-1
Absortion_cross_section_8000K_1atm_1cm-1.txt                   Absortion cross sections at T=8000K, p=1atm and Δν=1cm-1
Absortion_cross_section_10000K_1atm_1cm-1.txt                  Absortion cross sections at T=10000K, p=1atm and Δν=1cm-1
Absortion_cross_section_15000K_1atm_1cm-1.txt                  Absortion cross sections at T=15000K, p=1atm and Δν=1cm-1
Emission_cross_section_300K_1atm_1cm-1.txt                     Emission cross sections at T=300K, p=1atm and Δν=1cm-1
Emission_cross_section_1000K_1atm_1cm-1.txt                    Emission cross sections at T=1000K, p=1atm and Δν=1cm-1
Emission_cross_section_2000K_1atm_1cm-1.txt                    Emission cross sections at T=2000K, p=1atm and Δν=1cm-1
Emission_cross_section_3000K_1atm_1cm-1.txt                    Emission cross sections at T=3000K, p=1atm and Δν=1cm-1
Emission_cross_section_5000K_1atm_1cm-1.txt                    Emission cross sections at T=5000K, p=1atm and Δν=1cm-1
Emission_cross_section_8000K_1atm_1cm-1.txt                    Emission cross sections at T=8000K, p=1atm and Δν=1cm-1
Emission_cross_section_10000K_1atm_1cm-1.txt                   Emission cross sections at T=10000K, p=1atm and Δν=1cm-1
Emission_cross_section_15000K_1atm_1cm-1.txt                   Emission cross sections at T=15000K, p=1atm and Δν=1cm-1
Einstein coefficient _ A-X.txt                                 Einstein coefficients for the A-X transition
Einstein coefficient _ B-X.txt                                 Einstein coefficients for the B-X transition
Einstein coefficient _ C-X.txt                                 Einstein coefficients for the C-X transition
Einstein coefficient _ D-X.txt                                 Einstein coefficients for the D-X transition
PEC_doublet_states.txt                                         Ab initio potential energies of doublet states for AlO
PEC_quartet_states.txt                                         Ab initio potential energies of quartet states for AlO                
TDMs and PDMs_doublet_states.txt                               Ab initio dipole moments between doublet states for AlO
TDMs and PDMs_quartet_states.txt                               Ab initio dipole moments between quartet states for AlO
-----------------------------------------------------------------------------------------------------------------------

Byte-by-byte description of cross section files
-------------------------------------------------------------------------------
 Label   Units   Explanations
-------------------------------------------------------------------------------
   T     K       Temperature
   p    atm      Pressure
   Δν   cm-1     Spaced wavenumber
-------------------------------------------------------------------------------

Byte-by-byte description of Einstein coefficient_A-X files
-------------------------------------------------------------------------------
 Label                Units       Explanations
-------------------------------------------------------------------------------
   Al                  ---       Rotational quantum number of the A2Π state
   Xl                  ---       Rotational quantum number of the X2Σ+ state
   Av                  ---       Vibrational quantum number of the A2Π state
   Xv                  ---       Vibrational quantum number of the X2Σ+ state 
Einstein coefficient   s-1       Einstein coefficient of the transition
-------------------------------------------------------------------------------

Byte-by-byte description of Einstein coefficient_B-X files
-------------------------------------------------------------------------------
 Label                Units       Explanations
-------------------------------------------------------------------------------
   Bl                  ---       Rotational quantum number of the B2Σ+ state
   Xl                  ---       Rotational quantum number of the X2Σ+ state
   Bv                  ---       Vibrational quantum number of the B2Σ+ state
   Xv                  ---       Vibrational quantum number of the X2Σ+ state 
Einstein coefficient   s-1       Einstein coefficient of the transition
-------------------------------------------------------------------------------

Byte-by-byte description of Einstein coefficient_C-X files
-------------------------------------------------------------------------------
 Label                Units       Explanations
-------------------------------------------------------------------------------
   Cl                  ---       Rotational quantum number of the C2Π state
   Xl                  ---       Rotational quantum number of the X2Σ+ state
   Cv                  ---       Vibrational quantum number of the C2Π state
   Xv                  ---       Vibrational quantum number of the X2Σ+ state 
Einstein coefficient   s-1       Einstein coefficient of the transition
-------------------------------------------------------------------------------

Byte-by-byte description of Einstein coefficient_D-X files
-------------------------------------------------------------------------------
 Label                Units       Explanations
-------------------------------------------------------------------------------
   Dl                  ---       Rotational quantum number of the D2Σ+ state
   Xl                  ---       Rotational quantum number of the X2Σ+ state
   Dv                  ---       Vibrational quantum number of the D2Σ+ state
   Xv                  ---       Vibrational quantum number of the X2Σ+ state 
Einstein coefficient   s-1       Einstein coefficient of the transition
-------------------------------------------------------------------------------

Contacts:
   Zhi Qin, z.qin@sdu.edu.cn
   Linhua Liu, liulinhua@sdu.edu.cn
===============================================================================